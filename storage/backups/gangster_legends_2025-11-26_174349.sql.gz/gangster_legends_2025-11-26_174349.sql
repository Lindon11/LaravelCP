-- GLv2 Database Backup
-- Generated: 2025-11-26 17:43:49
-- Database: gangster_legends

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


-- Table: adminTasks
DROP TABLE IF EXISTS `adminTasks`;
CREATE TABLE `adminTasks` (
  `AT_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AT_title` varchar(200) NOT NULL,
  `AT_desc` text DEFAULT NULL,
  `AT_status` enum('backlog','todo','doing','done','archived') NOT NULL DEFAULT 'backlog',
  `AT_priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `AT_assignee` int(10) unsigned NOT NULL DEFAULT 0,
  `AT_due` int(10) unsigned DEFAULT NULL,
  `AT_order` int(10) unsigned NOT NULL DEFAULT 0,
  `AT_created` int(10) unsigned NOT NULL,
  `AT_updated` int(10) unsigned NOT NULL,
  PRIMARY KEY (`AT_id`),
  KEY `idx_status_order` (`AT_status`,`AT_order`,`AT_updated`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `adminTasks` VALUES ('1', 'test', 'test', 'todo', 'medium', '0', NULL, '0', '1761748135', '1763914581');


-- Table: backup_restore_history
DROP TABLE IF EXISTS `backup_restore_history`;
CREATE TABLE `backup_restore_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_id` int(11) NOT NULL,
  `backup_filename` varchar(255) NOT NULL,
  `restored_by` int(11) DEFAULT NULL,
  `restored_at` datetime NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 1,
  `error_message` text DEFAULT NULL,
  `safety_backup_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_backup_id` (`backup_id`),
  KEY `idx_restored_at` (`restored_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


-- Table: backup_settings
DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `backup_settings` VALUES ('1', 'backup_path', 'storage/backups/');
INSERT INTO `backup_settings` VALUES ('2', 'auto_backup_enabled', '0');
INSERT INTO `backup_settings` VALUES ('3', 'auto_backup_frequency', '86400');
INSERT INTO `backup_settings` VALUES ('4', 'max_backups_keep', '10');
INSERT INTO `backup_settings` VALUES ('5', 'compress_backups', '1');
INSERT INTO `backup_settings` VALUES ('6', 'backup_on_schedule', '0');
INSERT INTO `backup_settings` VALUES ('7', 'schedule_time', '03:00');


-- Table: backups
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `filesize` bigint(20) NOT NULL,
  `backup_type` enum('manual','automatic','scheduled') NOT NULL DEFAULT 'manual',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `database_name` varchar(100) NOT NULL,
  `table_count` int(11) NOT NULL DEFAULT 0,
  `compressed` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_backup_type` (`backup_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


-- Table: bank_transactions
DROP TABLE IF EXISTS `bank_transactions`;
CREATE TABLE `bank_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `transaction_type` enum('deposit','withdrawal','transfer_in','transfer_out','admin_adjust','crime_reward','theft_reward','blackjack_win','blackjack_loss','police_escape','marketplace_buy','marketplace_sell','bounty_reward','bounty_place','garage_buy','garage_sell','hospital','detective','travel','blackmarket','gang_expense') DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `balance_before` bigint(20) NOT NULL,
  `balance_after` bigint(20) NOT NULL,
  `related_user_id` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `transaction_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_time` (`transaction_time`),
  KEY `idx_type` (`transaction_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `bank_transactions` VALUES ('1', '1', 'crime_reward', '5', '1000', '1005', NULL, 'Crime completed successfully', NULL, '1763928345');
INSERT INTO `bank_transactions` VALUES ('2', '1', 'crime_reward', '5', '1005', '1010', NULL, 'Crime completed successfully', NULL, '1763928427');
INSERT INTO `bank_transactions` VALUES ('3', '1', 'marketplace_buy', '-10', '1000', '990', NULL, 'Marketplace purchase', NULL, '1763929572');
INSERT INTO `bank_transactions` VALUES ('4', '1', 'marketplace_buy', '-10', '990', '980', NULL, 'Marketplace purchase', NULL, '1763929575');
INSERT INTO `bank_transactions` VALUES ('5', '1', 'crime_reward', '5', '980', '985', NULL, 'Crime completed successfully', NULL, '1763929630');
INSERT INTO `bank_transactions` VALUES ('6', '1', 'blackjack_win', '200', '885', '1085', NULL, 'Blackjack win', NULL, '1763929644');


-- Table: bounties
DROP TABLE IF EXISTS `bounties`;
CREATE TABLE `bounties` (
  `B_id` int(11) NOT NULL AUTO_INCREMENT,
  `B_user` int(11) NOT NULL DEFAULT 0,
  `B_userToKill` int(11) NOT NULL DEFAULT 0,
  `B_cost` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`B_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: cars
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `CA_id` int(11) NOT NULL AUTO_INCREMENT,
  `CA_name` varchar(255) DEFAULT NULL,
  `CA_value` int(11) NOT NULL DEFAULT 0,
  `CA_theftChance` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`CA_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `cars` VALUES ('1', 'Peugeot 106', '400', '333');
INSERT INTO `cars` VALUES ('2', 'Citroen Saxo', '500', '333');
INSERT INTO `cars` VALUES ('3', 'Ford Fiesta', '600', '333');
INSERT INTO `cars` VALUES ('4', 'VW Golf', '1500', '250');
INSERT INTO `cars` VALUES ('5', 'Audi A3', '3200', '150');
INSERT INTO `cars` VALUES ('6', 'BMW 5 Series', '16000', '75');
INSERT INTO `cars` VALUES ('7', 'Porsche 911', '45000', '15');
INSERT INTO `cars` VALUES ('8', 'Ferrari California', '90000', '5');


-- Table: crime_attempts
DROP TABLE IF EXISTS `crime_attempts`;
CREATE TABLE `crime_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `crime_id` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  `reward` bigint(20) DEFAULT 0,
  `attempt_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_crime` (`crime_id`),
  KEY `idx_success` (`success`),
  KEY `idx_time` (`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `crime_attempts` VALUES ('1', '1', '1', '0', '0', '1763915757');
INSERT INTO `crime_attempts` VALUES ('2', '1', '1', '1', '1', '1763915778');
INSERT INTO `crime_attempts` VALUES ('3', '1', '1', '0', '0', '1763916077');
INSERT INTO `crime_attempts` VALUES ('4', '1', '1', '1', '4', '1763916105');
INSERT INTO `crime_attempts` VALUES ('5', '1', '1', '0', '0', '1763926184');
INSERT INTO `crime_attempts` VALUES ('6', '1', '1', '0', '0', '1763926838');
INSERT INTO `crime_attempts` VALUES ('7', '1', '1', '0', '0', '1763926860');
INSERT INTO `crime_attempts` VALUES ('8', '1', '1', '1', '4', '1763926882');
INSERT INTO `crime_attempts` VALUES ('9', '1', '1', '0', '0', '1763928261');
INSERT INTO `crime_attempts` VALUES ('10', '1', '1', '0', '0', '1763928289');
INSERT INTO `crime_attempts` VALUES ('11', '1', '1', '0', '0', '1763928323');
INSERT INTO `crime_attempts` VALUES ('12', '1', '1', '1', '5', '1763928345');
INSERT INTO `crime_attempts` VALUES ('13', '1', '1', '0', '0', '1763928381');
INSERT INTO `crime_attempts` VALUES ('14', '1', '1', '1', '5', '1763928427');
INSERT INTO `crime_attempts` VALUES ('15', '1', '1', '1', '5', '1763929630');


-- Table: crimes
DROP TABLE IF EXISTS `crimes`;
CREATE TABLE `crimes` (
  `C_id` int(11) NOT NULL AUTO_INCREMENT,
  `C_name` varchar(120) DEFAULT NULL,
  `C_cooldown` int(11) NOT NULL DEFAULT 0,
  `C_money` int(11) NOT NULL DEFAULT 0,
  `C_maxMoney` int(11) NOT NULL DEFAULT 0,
  `C_bullets` int(11) NOT NULL DEFAULT 0,
  `C_maxBullets` int(11) NOT NULL DEFAULT 0,
  `C_exp` int(11) NOT NULL DEFAULT 1,
  `C_level` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`C_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `crimes` VALUES ('1', 'Mug an old lady', '20', '1', '5', '0', '0', '1', '1');
INSERT INTO `crimes` VALUES ('2', 'Rob a cab driver', '45', '10', '18', '0', '0', '1', '1');


-- Table: detectives
DROP TABLE IF EXISTS `detectives`;
CREATE TABLE `detectives` (
  `D_id` int(11) NOT NULL AUTO_INCREMENT,
  `D_user` int(11) NOT NULL DEFAULT 0,
  `D_userToFind` int(11) NOT NULL DEFAULT 0,
  `D_detectives` int(11) NOT NULL DEFAULT 0,
  `D_start` int(11) NOT NULL DEFAULT 0,
  `D_end` int(11) NOT NULL DEFAULT 0,
  `D_success` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`D_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: economy_snapshots
DROP TABLE IF EXISTS `economy_snapshots`;
CREATE TABLE `economy_snapshots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `snapshot_time` int(11) NOT NULL,
  `total_money` bigint(20) DEFAULT 0,
  `total_bank` bigint(20) DEFAULT 0,
  `total_cash` bigint(20) DEFAULT 0,
  `total_players` int(11) DEFAULT 0,
  `active_players` int(11) DEFAULT 0,
  `avg_wealth` bigint(20) DEFAULT 0,
  `median_wealth` bigint(20) DEFAULT 0,
  `gini_coefficient` decimal(5,4) DEFAULT 0.0000,
  PRIMARY KEY (`id`),
  KEY `idx_time` (`snapshot_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


-- Table: email_exclude_list
DROP TABLE IF EXISTS `email_exclude_list`;
CREATE TABLE `email_exclude_list` (
  `EX_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EX_user_id` int(10) unsigned DEFAULT NULL,
  `EX_email` varchar(255) NOT NULL,
  `EX_reason` enum('opt-out','bounce','spam','admin') NOT NULL DEFAULT 'opt-out',
  `EX_added_by` int(10) unsigned DEFAULT NULL,
  `EX_added_time` int(10) unsigned NOT NULL,
  `EX_notes` text DEFAULT NULL,
  PRIMARY KEY (`EX_id`),
  UNIQUE KEY `idx_email` (`EX_email`),
  KEY `idx_user` (`EX_user_id`),
  KEY `idx_reason` (`EX_reason`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table: email_image_templates
DROP TABLE IF EXISTS `email_image_templates`;
CREATE TABLE `email_image_templates` (
  `EIT_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EIT_name` varchar(100) NOT NULL,
  `EIT_description` text DEFAULT NULL,
  `EIT_image_url` varchar(500) NOT NULL,
  `EIT_html` text NOT NULL,
  `EIT_width` int(10) unsigned DEFAULT NULL,
  `EIT_height` int(10) unsigned DEFAULT NULL,
  `EIT_category` enum('header','footer','banner','logo','button','divider','social','other') NOT NULL DEFAULT 'other',
  `EIT_created` int(10) unsigned NOT NULL,
  `EIT_use_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`EIT_id`),
  KEY `idx_category` (`EIT_category`),
  KEY `idx_name` (`EIT_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `email_image_templates` VALUES ('1', 'Simple Header', 'Basic header with game logo centered', '{siteurl}/themes/default/images/logo.png', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div>', '300', '100', 'header', '1762693431', '0');
INSERT INTO `email_image_templates` VALUES ('2', 'Footer with Social Links', 'Footer with game logo and copyright', '{siteurl}/themes/default/images/logo.png', '<div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '150', '50', 'footer', '1762693431', '0');
INSERT INTO `email_image_templates` VALUES ('3', 'Call to Action Button', 'Stylized button for CTAs', '', '<div style=\"text-align:center;padding:20px;\"><a href=\"[LINK]\" style=\"display:inline-block;padding:15px 30px;background:#007bff;color:#fff;text-decoration:none;border-radius:5px;font-weight:bold;\">Click Here</a></div>', '200', '50', 'button', '1762693431', '0');
INSERT INTO `email_image_templates` VALUES ('4', 'Horizontal Divider', 'Decorative line separator', '', '<div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div>', '600', '2', 'divider', '1762693431', '0');


-- Table: email_templates
DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `ET_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ET_name` varchar(100) NOT NULL,
  `ET_subject` varchar(255) NOT NULL,
  `ET_body` text NOT NULL,
  `ET_is_html` tinyint(1) NOT NULL DEFAULT 0,
  `ET_created` int(10) unsigned NOT NULL,
  `ET_last_used` int(10) unsigned DEFAULT NULL,
  `ET_use_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ET_id`),
  KEY `idx_name` (`ET_name`),
  KEY `idx_last_used` (`ET_last_used`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `email_templates` VALUES ('1', 'Welcome Email', 'Welcome to {gamename}!', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><p>Welcome to the game! We\'re glad to have you here.</p><p>Your starting stats:</p><ul><li>Level: <strong>{level}</strong></li><li>Money: <strong>${money}</strong></li></ul><p>Good luck!</p><p>The Admin Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('2', 'Password Reset', 'Reset Your Password - {gamename}', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><p>We received a request to reset your password for your account at {gamename}.</p><div style=\"text-align:center;padding:20px;\"><a href=\"[RESET_LINK]\" style=\"display:inline-block;padding:15px 30px;background:#007bff;color:#fff;text-decoration:none;border-radius:5px;font-weight:bold;\">Reset Password</a></div><p>If you didn\'t request this, please ignore this email. Your password will remain unchanged.</p><p style=\"color:#999;font-size:12px;\">For security reasons, this link will expire in 24 hours.</p><p>Best regards,<br>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('3', 'Account Suspended', 'Account Status Update - {gamename}', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><p style=\"color:#d9534f;\"><strong>⚠️ Your account at {gamename} has been temporarily suspended.</strong></p><p><strong>Reason:</strong> [REASON]</p><p>If you believe this is a mistake or have questions, please contact our support team.</p><p>The Admin Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('4', 'Level Up Congratulations', 'Congratulations on reaching Level {level}!', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hey <strong>{username}</strong>! 🎉</p><h2 style=\"color:#5cb85c;\">Congratulations! You\'ve just reached level {level}!</h2><p>Your current stats:</p><ul><li>Level: <strong>{level}</strong></li><li>Money: <strong>${money}</strong></li><li>Gang: <strong>{gang}</strong></li></ul><p>Keep up the great work!</p><p>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('5', 'Weekly Update', 'Your Weekly Update - {gamename}', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><h2>Here\'s your weekly update from {gamename}:</h2><h3>📊 Your Stats:</h3><ul><li>Level: <strong>{level}</strong></li><li>Money: <strong>${money}</strong></li><li>Gang: <strong>{gang}</strong></li></ul><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;\" /></div><h3>🎯 This Week\'s Events:</h3><p>[EVENTS_LIST]</p><h3>💰 Special Offers:</h3><p>[OFFERS_LIST]</p><p>Keep playing and dominating!</p><p>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('6', 'Gang Invitation', 'You\'ve been invited to join {gang}!', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><h2 style=\"color:#5cb85c;\">You\'ve received an invitation to join the gang \"{gang}\" in {gamename}!</h2><p><strong>Current Members:</strong> [MEMBER_COUNT]<br><strong>Gang Level:</strong> [GANG_LEVEL]</p><div style=\"text-align:center;padding:20px;\"><a href=\"[ACCEPT_LINK]\" style=\"display:inline-block;padding:15px 30px;background:#5cb85c;color:#fff;text-decoration:none;border-radius:5px;font-weight:bold;\">Accept Invitation</a></div><p style=\"text-align:center;\">Log in now to accept or decline the invitation.</p><p>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('7', 'Inactivity Warning', 'We miss you at {gamename}!', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hey <strong>{username}</strong>,</p><h2>We miss you! 😢</h2><p>We noticed you haven\'t logged into {gamename} for a while.</p><p>Your account status:</p><ul><li>Level: <strong>{level}</strong></li><li>Money: <strong>${money}</strong></li><li>Gang: <strong>{gang}</strong></li></ul><p>Come back and see what\'s new! There have been some exciting updates since your last visit.</p><div style=\"text-align:center;padding:20px;\"><a href=\"[LOGIN_LINK]\" style=\"display:inline-block;padding:15px 30px;background:#007bff;color:#fff;text-decoration:none;border-radius:5px;font-weight:bold;\">Log In Now</a></div><p>See you soon!<br>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');
INSERT INTO `email_templates` VALUES ('8', 'Premium Membership', 'Thank you for your Premium Membership!', '<div style=\"text-align:center;padding:20px;background:#f4f4f4;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:300px;height:auto;\" /></div><div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;\"><p>Hi <strong>{username}</strong>,</p><h2 style=\"color:#f0ad4e;\">✨ Thank you for your Premium Membership!</h2><p>Thank you for supporting {gamename} with a Premium Membership!</p><h3>Your Premium Benefits:</h3><ul><li>✓ Exclusive items and features</li><li>✓ Priority support</li><li>✓ Special badge</li><li>✓ Extra bonuses</li></ul><p>Your support helps us keep the game running and improving.</p><p><strong>Enjoy your premium experience!</strong></p><p>The {gamename} Team</p></div><div style=\"padding:20px 0;\"><hr style=\"border:none;border-top:2px solid #ddd;margin:0 auto;max-width:600px;\" /></div><div style=\"text-align:center;padding:20px;background:#333;color:#fff;\"><img src=\"{siteurl}/themes/default/images/logo.png\" alt=\"{gamename}\" style=\"max-width:150px;height:auto;margin-bottom:10px;\" /><p style=\"font-size:12px;color:#999;\">© 2025 {gamename}. All rights reserved.</p></div>', '1', '1762693431', NULL, '0');


-- Table: failed_logins
DROP TABLE IF EXISTS `failed_logins`;
CREATE TABLE `failed_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempted_username` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `attempt_time` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`attempted_username`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_time` (`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `failed_logins` VALUES ('1', 'admin@test.com', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0', '1763907281', '0');
INSERT INTO `failed_logins` VALUES ('2', 'admin@test.com', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0', '1763907381', '0');
INSERT INTO `failed_logins` VALUES ('3', 'admin@test.com', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0', '1763907481', '0');
INSERT INTO `failed_logins` VALUES ('4', 'john@example.com', '10.0.0.50', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/14.0', '1763903681', '0');
INSERT INTO `failed_logins` VALUES ('5', 'hacker@evil.com', '203.0.113.45', 'Python-urllib/3.8', '1763909081', '0');
INSERT INTO `failed_logins` VALUES ('6', 'test@test.com', '203.0.113.45', 'Python-urllib/3.8', '1763909131', '0');
INSERT INTO `failed_logins` VALUES ('7', 'admin@test.com', '203.0.113.45', 'Python-urllib/3.8', '1763909181', '0');
INSERT INTO `failed_logins` VALUES ('8', 'root@test.com', '203.0.113.45', 'Python-urllib/3.8', '1763909231', '0');
INSERT INTO `failed_logins` VALUES ('9', 'user@test.com', '203.0.113.45', 'Python-urllib/3.8', '1763909281', '0');
INSERT INTO `failed_logins` VALUES ('10', 'admin@test.com', '203.0.113.45', 'Python-urllib/3.8', '1763909331', '0');
INSERT INTO `failed_logins` VALUES ('11', 'sarah@example.com', '172.16.0.25', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) Mobile/15E148', '1763910581', '0');
INSERT INTO `failed_logins` VALUES ('12', 'mike@test.com', '192.168.1.200', 'Mozilla/5.0 (X11; Linux x86_64) Firefox/89.0', '1763910761', '0');


-- Table: forumAccess
DROP TABLE IF EXISTS `forumAccess`;
CREATE TABLE `forumAccess` (
  `FA_role` int(11) DEFAULT NULL,
  `FA_forum` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: forums
DROP TABLE IF EXISTS `forums`;
CREATE TABLE `forums` (
  `F_id` int(11) NOT NULL AUTO_INCREMENT,
  `F_sort` int(11) NOT NULL DEFAULT 0,
  `F_name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`F_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `forums` VALUES ('1', '1', 'Game Forum');


-- Table: gameNews
DROP TABLE IF EXISTS `gameNews`;
CREATE TABLE `gameNews` (
  `GN_id` int(11) NOT NULL AUTO_INCREMENT,
  `GN_author` int(11) NOT NULL DEFAULT 0,
  `GN_title` varchar(120) DEFAULT NULL,
  `GN_text` text DEFAULT NULL,
  `GN_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`GN_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `gameNews` VALUES ('1', '1', 'Instalation Complete', 'GL v2 successfully installed', '1761577288');


-- Table: gangInvites
DROP TABLE IF EXISTS `gangInvites`;
CREATE TABLE `gangInvites` (
  `GI_id` int(11) NOT NULL AUTO_INCREMENT,
  `GI_user` int(11) NOT NULL,
  `GI_gangUser` int(11) NOT NULL,
  `GI_gang` int(11) NOT NULL,
  PRIMARY KEY (`GI_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: gangLogs
DROP TABLE IF EXISTS `gangLogs`;
CREATE TABLE `gangLogs` (
  `GL_id` int(11) NOT NULL AUTO_INCREMENT,
  `GL_gang` int(11) NOT NULL,
  `GL_time` int(11) NOT NULL,
  `GL_user` int(11) NOT NULL,
  `GL_log` varchar(255) NOT NULL,
  PRIMARY KEY (`GL_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: gangPermissions
DROP TABLE IF EXISTS `gangPermissions`;
CREATE TABLE `gangPermissions` (
  `GP_id` int(11) NOT NULL AUTO_INCREMENT,
  `GP_user` int(11) NOT NULL,
  `GP_access` varchar(128) NOT NULL,
  PRIMARY KEY (`GP_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: gangs
DROP TABLE IF EXISTS `gangs`;
CREATE TABLE `gangs` (
  `G_id` int(11) NOT NULL AUTO_INCREMENT,
  `G_name` varchar(120) DEFAULT NULL,
  `G_bank` int(11) NOT NULL DEFAULT 0,
  `G_money` int(11) NOT NULL DEFAULT 0,
  `G_bullets` int(11) NOT NULL DEFAULT 0,
  `G_info` text DEFAULT NULL,
  `G_desc` text DEFAULT NULL,
  `G_location` int(11) NOT NULL DEFAULT 0,
  `G_boss` int(11) NOT NULL DEFAULT 0,
  `G_underboss` int(11) NOT NULL DEFAULT 0,
  `G_level` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`G_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: garage
DROP TABLE IF EXISTS `garage`;
CREATE TABLE `garage` (
  `GA_id` int(11) NOT NULL AUTO_INCREMENT,
  `GA_uid` int(11) NOT NULL DEFAULT 0,
  `GA_car` int(11) NOT NULL DEFAULT 0,
  `GA_damage` int(11) NOT NULL DEFAULT 0,
  `GA_location` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`GA_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: health_alerts
DROP TABLE IF EXISTS `health_alerts`;
CREATE TABLE `health_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(50) NOT NULL,
  `threshold_value` decimal(10,2) NOT NULL,
  `alert_type` enum('warning','critical') NOT NULL,
  `email_recipients` text DEFAULT NULL,
  `last_alert_time` int(11) DEFAULT 0,
  `alert_cooldown` int(11) DEFAULT 3600,
  `enabled` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_metric` (`metric_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


-- Table: health_metrics
DROP TABLE IF EXISTS `health_metrics`;
CREATE TABLE `health_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(50) NOT NULL,
  `metric_value` decimal(12,2) NOT NULL,
  `metric_data` text DEFAULT NULL,
  `recorded_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_type_time` (`metric_type`,`recorded_time`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `health_metrics` VALUES ('1', 'memory_usage', '45.50', '{\"used\":100000,\"limit\":200000}', '1763930243');
INSERT INTO `health_metrics` VALUES ('2', 'memory_usage', '0.39', '{\"used\":2097152,\"limit\":536870912}', '1763930305');
INSERT INTO `health_metrics` VALUES ('3', 'disk_usage', '2.35', '{\"used\":3991900160,\"total\":169617965056}', '1763930305');
INSERT INTO `health_metrics` VALUES ('4', 'db_connections', '1.00', '{\"connections\":1}', '1763930305');
INSERT INTO `health_metrics` VALUES ('5', 'memory_usage', '0.39', '{\"used\":2097152,\"limit\":536870912,\"percent\":0.39,\"formatted_used\":\"2 MB\",\"formatted_limit\":\"512M\"}', '1763930558');
INSERT INTO `health_metrics` VALUES ('6', 'disk_usage', '2.35', '{\"used\":3991957504,\"free\":165612605440,\"total\":169604562944,\"percent\":2.35,\"formatted_used\":\"3.72 GB\",\"formatted_free\":\"154.24 GB\",\"formatted_total\":\"157.96 GB\"}', '1763930558');
INSERT INTO `health_metrics` VALUES ('7', 'db_connections', '1.00', '{\"connections\":1,\"total_size\":\"1490944\",\"data_size\":\"884736\",\"index_size\":\"606208\",\"formatted_size\":\"1.42 MB\",\"version\":\"12.0.2-MariaDB-ubu2404\"}', '1763930558');
INSERT INTO `health_metrics` VALUES ('8', 'memory_usage', '0.40', '{\"used\":2097152,\"limit\":536870912,\"percent\":0.4,\"formatted_used\":\"2 MB\",\"formatted_limit\":\"512M\"}', '1763930775');
INSERT INTO `health_metrics` VALUES ('9', 'disk_usage', '2.40', '{\"used\":3992080384,\"free\":165626953728,\"total\":169619034112,\"percent\":2.4,\"formatted_used\":\"3.72 GB\",\"formatted_free\":\"154.25 GB\",\"formatted_total\":\"157.97 GB\"}', '1763930775');
INSERT INTO `health_metrics` VALUES ('10', 'db_connections', '1.00', '{\"connections\":1,\"total_size\":\"1490944\",\"data_size\":\"884736\",\"index_size\":\"606208\",\"formatted_size\":\"1.42 MB\",\"version\":\"12.0.2-MariaDB-ubu2404\"}', '1763930775');
INSERT INTO `health_metrics` VALUES ('11', 'memory_usage', '0.40', '{\"used\":2097152,\"limit\":536870912,\"percent\":0.4,\"formatted_used\":\"2 MB\",\"formatted_limit\":\"512M\"}', '1763930844');
INSERT INTO `health_metrics` VALUES ('12', 'disk_usage', '2.40', '{\"used\":3992080384,\"free\":165617958912,\"total\":169610039296,\"percent\":2.4,\"formatted_used\":\"3.72 GB\",\"formatted_free\":\"154.24 GB\",\"formatted_total\":\"157.96 GB\"}', '1763930844');
INSERT INTO `health_metrics` VALUES ('13', 'db_connections', '1.00', '{\"connections\":1,\"total_size\":\"1490944\",\"data_size\":\"884736\",\"index_size\":\"606208\",\"formatted_size\":\"1.42 MB\",\"version\":\"12.0.2-MariaDB-ubu2404\"}', '1763930844');
INSERT INTO `health_metrics` VALUES ('14', 'memory_usage', '0.40', '{\"used\":2097152,\"limit\":536870912,\"percent\":0.4,\"formatted_used\":\"2 MB\",\"formatted_limit\":\"512M\"}', '1763930907');
INSERT INTO `health_metrics` VALUES ('15', 'disk_usage', '2.40', '{\"used\":3992100864,\"free\":165617938432,\"total\":169610039296,\"percent\":2.4,\"formatted_used\":\"3.72 GB\",\"formatted_free\":\"154.24 GB\",\"formatted_total\":\"157.96 GB\"}', '1763930907');
INSERT INTO `health_metrics` VALUES ('16', 'db_connections', '1.00', '{\"connections\":1,\"total_size\":\"1490944\",\"data_size\":\"884736\",\"index_size\":\"606208\",\"formatted_size\":\"1.42 MB\",\"version\":\"12.0.2-MariaDB-ubu2404\"}', '1763930907');
INSERT INTO `health_metrics` VALUES ('17', 'memory_usage', '0.40', NULL, '1763931387');
INSERT INTO `health_metrics` VALUES ('18', 'disk_usage', '2.40', NULL, '1763931387');
INSERT INTO `health_metrics` VALUES ('19', 'db_connections', '1.00', NULL, '1763931387');
INSERT INTO `health_metrics` VALUES ('20', 'memory_usage', '0.40', NULL, '1763931451');
INSERT INTO `health_metrics` VALUES ('21', 'disk_usage', '2.40', NULL, '1763931451');
INSERT INTO `health_metrics` VALUES ('22', 'db_connections', '1.00', NULL, '1763931451');
INSERT INTO `health_metrics` VALUES ('23', 'memory_usage', '0.40', NULL, '1763931503');
INSERT INTO `health_metrics` VALUES ('24', 'disk_usage', '2.40', NULL, '1763931503');
INSERT INTO `health_metrics` VALUES ('25', 'db_connections', '1.00', NULL, '1763931503');
INSERT INTO `health_metrics` VALUES ('26', 'memory_usage', '0.40', NULL, '1763931587');
INSERT INTO `health_metrics` VALUES ('27', 'disk_usage', '2.40', NULL, '1763931587');
INSERT INTO `health_metrics` VALUES ('28', 'db_connections', '1.00', NULL, '1763931587');
INSERT INTO `health_metrics` VALUES ('29', 'memory_usage', '0.40', NULL, '1763931623');
INSERT INTO `health_metrics` VALUES ('30', 'disk_usage', '2.40', NULL, '1763931623');
INSERT INTO `health_metrics` VALUES ('31', 'db_connections', '1.00', NULL, '1763931623');
INSERT INTO `health_metrics` VALUES ('32', 'memory_usage', '0.40', NULL, '1763931633');
INSERT INTO `health_metrics` VALUES ('33', 'disk_usage', '2.40', NULL, '1763931633');
INSERT INTO `health_metrics` VALUES ('34', 'db_connections', '1.00', NULL, '1763931633');
INSERT INTO `health_metrics` VALUES ('35', 'memory_usage', '0.40', NULL, '1763931655');
INSERT INTO `health_metrics` VALUES ('36', 'disk_usage', '2.40', NULL, '1763931655');
INSERT INTO `health_metrics` VALUES ('37', 'db_connections', '1.00', NULL, '1763931655');
INSERT INTO `health_metrics` VALUES ('38', 'memory_usage', '0.40', NULL, '1763931763');
INSERT INTO `health_metrics` VALUES ('39', 'disk_usage', '2.40', NULL, '1763931763');
INSERT INTO `health_metrics` VALUES ('40', 'db_connections', '1.00', NULL, '1763931763');
INSERT INTO `health_metrics` VALUES ('41', 'memory_usage', '0.40', NULL, '1763931849');
INSERT INTO `health_metrics` VALUES ('42', 'disk_usage', '2.40', NULL, '1763931849');
INSERT INTO `health_metrics` VALUES ('43', 'db_connections', '1.00', NULL, '1763931849');
INSERT INTO `health_metrics` VALUES ('44', 'memory_usage', '0.40', NULL, '1763931866');
INSERT INTO `health_metrics` VALUES ('45', 'disk_usage', '2.40', NULL, '1763931866');
INSERT INTO `health_metrics` VALUES ('46', 'db_connections', '1.00', NULL, '1763931866');
INSERT INTO `health_metrics` VALUES ('47', 'memory_usage', '0.40', NULL, '1763931912');
INSERT INTO `health_metrics` VALUES ('48', 'disk_usage', '2.40', NULL, '1763931912');
INSERT INTO `health_metrics` VALUES ('49', 'db_connections', '1.00', NULL, '1763931912');
INSERT INTO `health_metrics` VALUES ('50', 'memory_usage', '0.40', NULL, '1763931914');
INSERT INTO `health_metrics` VALUES ('51', 'disk_usage', '2.40', NULL, '1763931914');
INSERT INTO `health_metrics` VALUES ('52', 'db_connections', '1.00', NULL, '1763931914');
INSERT INTO `health_metrics` VALUES ('53', 'memory_usage', '0.40', NULL, '1763931970');
INSERT INTO `health_metrics` VALUES ('54', 'disk_usage', '2.40', NULL, '1763931970');
INSERT INTO `health_metrics` VALUES ('55', 'db_connections', '1.00', NULL, '1763931970');
INSERT INTO `health_metrics` VALUES ('56', 'memory_usage', '0.40', NULL, '1763932016');
INSERT INTO `health_metrics` VALUES ('57', 'disk_usage', '2.40', NULL, '1763932016');
INSERT INTO `health_metrics` VALUES ('58', 'db_connections', '1.00', NULL, '1763932016');
INSERT INTO `health_metrics` VALUES ('59', 'memory_usage', '0.40', NULL, '1763932017');
INSERT INTO `health_metrics` VALUES ('60', 'disk_usage', '2.40', NULL, '1763932017');
INSERT INTO `health_metrics` VALUES ('61', 'db_connections', '1.00', NULL, '1763932017');
INSERT INTO `health_metrics` VALUES ('62', 'memory_usage', '0.40', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('63', 'disk_usage', '2.40', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('64', 'db_connections', '1.00', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('65', 'memory_usage', '0.40', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('66', 'disk_usage', '2.40', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('67', 'db_connections', '1.00', NULL, '1763932018');
INSERT INTO `health_metrics` VALUES ('68', 'memory_usage', '0.40', NULL, '1763932030');
INSERT INTO `health_metrics` VALUES ('69', 'disk_usage', '2.40', NULL, '1763932030');
INSERT INTO `health_metrics` VALUES ('70', 'db_connections', '1.00', NULL, '1763932030');
INSERT INTO `health_metrics` VALUES ('71', 'memory_usage', '0.40', NULL, '1763932084');
INSERT INTO `health_metrics` VALUES ('72', 'disk_usage', '2.40', NULL, '1763932084');
INSERT INTO `health_metrics` VALUES ('73', 'db_connections', '1.00', NULL, '1763932084');
INSERT INTO `health_metrics` VALUES ('74', 'memory_usage', '0.40', NULL, '1763932141');
INSERT INTO `health_metrics` VALUES ('75', 'disk_usage', '2.40', NULL, '1763932141');
INSERT INTO `health_metrics` VALUES ('76', 'db_connections', '1.00', NULL, '1763932141');
INSERT INTO `health_metrics` VALUES ('77', 'memory_usage', '0.40', NULL, '1763932251');
INSERT INTO `health_metrics` VALUES ('78', 'disk_usage', '2.40', NULL, '1763932251');
INSERT INTO `health_metrics` VALUES ('79', 'db_connections', '1.00', NULL, '1763932251');
INSERT INTO `health_metrics` VALUES ('80', 'memory_usage', '0.40', NULL, '1763932295');
INSERT INTO `health_metrics` VALUES ('81', 'disk_usage', '2.40', NULL, '1763932295');
INSERT INTO `health_metrics` VALUES ('82', 'db_connections', '1.00', NULL, '1763932295');
INSERT INTO `health_metrics` VALUES ('83', 'memory_usage', '0.40', NULL, '1763932327');
INSERT INTO `health_metrics` VALUES ('84', 'disk_usage', '2.40', NULL, '1763932327');
INSERT INTO `health_metrics` VALUES ('85', 'db_connections', '1.00', NULL, '1763932327');
INSERT INTO `health_metrics` VALUES ('86', 'memory_usage', '0.40', NULL, '1763932362');
INSERT INTO `health_metrics` VALUES ('87', 'disk_usage', '2.40', NULL, '1763932362');
INSERT INTO `health_metrics` VALUES ('88', 'db_connections', '1.00', NULL, '1763932362');
INSERT INTO `health_metrics` VALUES ('89', 'memory_usage', '0.40', NULL, '1763932472');
INSERT INTO `health_metrics` VALUES ('90', 'disk_usage', '2.40', NULL, '1763932472');
INSERT INTO `health_metrics` VALUES ('91', 'db_connections', '1.00', NULL, '1763932472');
INSERT INTO `health_metrics` VALUES ('92', 'memory_usage', '0.40', NULL, '1763932800');
INSERT INTO `health_metrics` VALUES ('93', 'disk_usage', '2.40', NULL, '1763932800');
INSERT INTO `health_metrics` VALUES ('94', 'db_connections', '1.00', NULL, '1763932800');
INSERT INTO `health_metrics` VALUES ('95', 'memory_usage', '0.40', NULL, '1763933138');
INSERT INTO `health_metrics` VALUES ('96', 'disk_usage', '2.40', NULL, '1763933138');
INSERT INTO `health_metrics` VALUES ('97', 'db_connections', '1.00', NULL, '1763933138');
INSERT INTO `health_metrics` VALUES ('98', 'memory_usage', '0.40', NULL, '1763933534');
INSERT INTO `health_metrics` VALUES ('99', 'disk_usage', '2.40', NULL, '1763933534');
INSERT INTO `health_metrics` VALUES ('100', 'db_connections', '1.00', NULL, '1763933534');
INSERT INTO `health_metrics` VALUES ('101', 'cpu_usage', '11.05', '{\"load\":[0.44189453125,0.2353515625,0.1884765625]}', '1763933640');
INSERT INTO `health_metrics` VALUES ('102', 'network_rx', '83.27', '{\"rx\":87313497}', '1763933640');
INSERT INTO `health_metrics` VALUES ('103', 'network_tx', '301.41', '{\"tx\":316050588}', '1763933640');
INSERT INTO `health_metrics` VALUES ('104', 'cpu_usage', '9.34', '{\"load\":[0.37353515625,0.22705078125,0.185546875]}', '1763933649');
INSERT INTO `health_metrics` VALUES ('105', 'network_rx', '83.30', '{\"rx\":87343981}', '1763933649');
INSERT INTO `health_metrics` VALUES ('106', 'network_tx', '301.67', '{\"tx\":316323154}', '1763933649');
INSERT INTO `health_metrics` VALUES ('107', 'cpu_usage', '9.34', '{\"load\":[0.37353515625,0.22705078125,0.185546875]}', '1763933650');
INSERT INTO `health_metrics` VALUES ('108', 'network_rx', '83.30', '{\"rx\":87345043}', '1763933650');
INSERT INTO `health_metrics` VALUES ('109', 'network_tx', '301.67', '{\"tx\":316324651}', '1763933650');
INSERT INTO `health_metrics` VALUES ('110', 'cpu_usage', '9.34', '{\"load\":[0.37353515625,0.22705078125,0.185546875]}', '1763933652');
INSERT INTO `health_metrics` VALUES ('111', 'network_rx', '83.30', '{\"rx\":87346105}', '1763933652');
INSERT INTO `health_metrics` VALUES ('112', 'network_tx', '301.67', '{\"tx\":316326146}', '1763933652');
INSERT INTO `health_metrics` VALUES ('113', 'cpu_usage', '8.58', '{\"load\":[0.34326171875,0.22314453125,0.18408203125]}', '1763933653');
INSERT INTO `health_metrics` VALUES ('114', 'network_rx', '83.30', '{\"rx\":87347167}', '1763933653');
INSERT INTO `health_metrics` VALUES ('115', 'network_tx', '301.67', '{\"tx\":316327643}', '1763933653');
INSERT INTO `health_metrics` VALUES ('116', 'cpu_usage', '8.58', '{\"load\":[0.34326171875,0.22314453125,0.18408203125]}', '1763933654');
INSERT INTO `health_metrics` VALUES ('117', 'network_rx', '83.30', '{\"rx\":87348229}', '1763933654');
INSERT INTO `health_metrics` VALUES ('118', 'network_tx', '301.67', '{\"tx\":316329142}', '1763933654');
INSERT INTO `health_metrics` VALUES ('119', 'cpu_usage', '8.58', '{\"load\":[0.34326171875,0.22314453125,0.18408203125]}', '1763933655');
INSERT INTO `health_metrics` VALUES ('120', 'network_rx', '83.30', '{\"rx\":87349291}', '1763933655');
INSERT INTO `health_metrics` VALUES ('121', 'network_tx', '301.68', '{\"tx\":316330641}', '1763933655');
INSERT INTO `health_metrics` VALUES ('122', 'cpu_usage', '8.58', '{\"load\":[0.34326171875,0.22314453125,0.18408203125]}', '1763933656');
INSERT INTO `health_metrics` VALUES ('123', 'network_rx', '83.31', '{\"rx\":87357536}', '1763933656');
INSERT INTO `health_metrics` VALUES ('124', 'network_tx', '301.69', '{\"tx\":316340828}', '1763933656');
INSERT INTO `health_metrics` VALUES ('125', 'cpu_usage', '8.58', '{\"load\":[0.34326171875,0.22314453125,0.18408203125]}', '1763933657');
INSERT INTO `health_metrics` VALUES ('126', 'network_rx', '83.31', '{\"rx\":87358598}', '1763933657');
INSERT INTO `health_metrics` VALUES ('127', 'network_tx', '301.69', '{\"tx\":316342327}', '1763933657');
INSERT INTO `health_metrics` VALUES ('128', 'cpu_usage', '7.89', '{\"load\":[0.3154296875,0.21923828125,0.1826171875]}', '1763933658');
INSERT INTO `health_metrics` VALUES ('129', 'network_rx', '83.31', '{\"rx\":87359660}', '1763933658');
INSERT INTO `health_metrics` VALUES ('130', 'network_tx', '301.69', '{\"tx\":316343826}', '1763933658');
INSERT INTO `health_metrics` VALUES ('131', 'cpu_usage', '7.89', '{\"load\":[0.3154296875,0.21923828125,0.1826171875]}', '1763933659');
INSERT INTO `health_metrics` VALUES ('132', 'network_rx', '83.31', '{\"rx\":87360725}', '1763933659');
INSERT INTO `health_metrics` VALUES ('133', 'network_tx', '301.69', '{\"tx\":316345322}', '1763933659');
INSERT INTO `health_metrics` VALUES ('134', 'memory_usage', '0.40', NULL, '1763933688');
INSERT INTO `health_metrics` VALUES ('135', 'disk_usage', '2.40', NULL, '1763933688');
INSERT INTO `health_metrics` VALUES ('136', 'db_connections', '1.00', NULL, '1763933688');
INSERT INTO `health_metrics` VALUES ('137', 'memory_usage', '0.40', NULL, '1763933861');
INSERT INTO `health_metrics` VALUES ('138', 'disk_usage', '2.40', NULL, '1763933861');
INSERT INTO `health_metrics` VALUES ('139', 'db_connections', '1.00', NULL, '1763933861');
INSERT INTO `health_metrics` VALUES ('140', 'memory_usage', '0.40', NULL, '1763934161');
INSERT INTO `health_metrics` VALUES ('141', 'disk_usage', '2.40', NULL, '1763934161');
INSERT INTO `health_metrics` VALUES ('142', 'db_connections', '1.00', NULL, '1763934161');
INSERT INTO `health_metrics` VALUES ('143', 'memory_usage', '0.40', NULL, '1763934194');
INSERT INTO `health_metrics` VALUES ('144', 'disk_usage', '2.40', NULL, '1763934194');
INSERT INTO `health_metrics` VALUES ('145', 'db_connections', '1.00', NULL, '1763934194');
INSERT INTO `health_metrics` VALUES ('146', 'memory_usage', '0.40', NULL, '1763934467');
INSERT INTO `health_metrics` VALUES ('147', 'disk_usage', '2.40', NULL, '1763934467');
INSERT INTO `health_metrics` VALUES ('148', 'db_connections', '1.00', NULL, '1763934467');
INSERT INTO `health_metrics` VALUES ('149', 'memory_usage', '0.40', NULL, '1763934481');
INSERT INTO `health_metrics` VALUES ('150', 'disk_usage', '2.40', NULL, '1763934481');
INSERT INTO `health_metrics` VALUES ('151', 'db_connections', '1.00', NULL, '1763934481');
INSERT INTO `health_metrics` VALUES ('152', 'memory_usage', '0.40', NULL, '1763934487');
INSERT INTO `health_metrics` VALUES ('153', 'disk_usage', '2.40', NULL, '1763934487');
INSERT INTO `health_metrics` VALUES ('154', 'db_connections', '1.00', NULL, '1763934487');
INSERT INTO `health_metrics` VALUES ('155', 'memory_usage', '0.40', NULL, '1763936283');
INSERT INTO `health_metrics` VALUES ('156', 'disk_usage', '2.40', NULL, '1763936283');
INSERT INTO `health_metrics` VALUES ('157', 'db_connections', '1.00', NULL, '1763936283');
INSERT INTO `health_metrics` VALUES ('158', 'memory_usage', '0.40', NULL, '1763936288');
INSERT INTO `health_metrics` VALUES ('159', 'disk_usage', '2.40', NULL, '1763936288');
INSERT INTO `health_metrics` VALUES ('160', 'db_connections', '1.00', NULL, '1763936288');


-- Table: health_slow_queries
DROP TABLE IF EXISTS `health_slow_queries`;
CREATE TABLE `health_slow_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query_text` text NOT NULL,
  `execution_time` decimal(10,4) NOT NULL,
  `rows_examined` int(11) DEFAULT NULL,
  `rows_sent` int(11) DEFAULT NULL,
  `detected_time` int(11) NOT NULL,
  `query_hash` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_time` (`detected_time`),
  KEY `idx_exec_time` (`execution_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `health_slow_queries` VALUES ('1', 'SELECT * FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.created_at > DATE_SUB(NOW(), INTERVAL 1 YEAR) ORDER BY u.last_login DESC', '2.3456', '15000', '500', '1763934011', '1fc6682a6123b1da333ef18ad6c3bc46');
INSERT INTO `health_slow_queries` VALUES ('2', 'UPDATE game_stats SET score = score + 1 WHERE player_id IN (SELECT id FROM players WHERE active = 1 AND level > 10)', '5.7821', '50000', '0', '1763930411', '6445bfd88f2bb1e3759d2e3dd88fe36d');
INSERT INTO `health_slow_queries` VALUES ('3', 'SELECT COUNT(*) as total, category FROM items WHERE status = \"available\" GROUP BY category HAVING total > 100', '1.2345', '8000', '25', '1763926811', 'b18cb721b836438ab9f5423affddedaa');
INSERT INTO `health_slow_queries` VALUES ('4', 'DELETE FROM logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY) AND log_level != \"error\"', '3.4567', '100000', '0', '1763923211', 'd4d4acb2faaeb6f14a752c1381cb0596');
INSERT INTO `health_slow_queries` VALUES ('5', 'SELECT SLEEP(3) as test, \'This is a slow query\' as message', '3.0070', '1', '1', '1763934379', 'bdda8658f5c50d0ad2269f3b94e9196f');


-- Table: ip_blocks
DROP TABLE IF EXISTS `ip_blocks`;
CREATE TABLE `ip_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` text DEFAULT NULL,
  `blocked_by` varchar(100) DEFAULT NULL,
  `blocked_time` int(11) NOT NULL,
  `expires_time` int(11) DEFAULT NULL,
  `is_permanent` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_expires` (`expires_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `ip_blocks` VALUES ('1', '203.0.113.45', 'Multiple failed login attempts - brute force attack', 'Admin', '1763911272', NULL, '1');
INSERT INTO `ip_blocks` VALUES ('2', '198.51.100.20', 'Suspicious activity detected', 'System', '1763907672', '1763994072', '0');


-- Table: itemEffects
DROP TABLE IF EXISTS `itemEffects`;
CREATE TABLE `itemEffects` (
  `IE_effect` varchar(32) NOT NULL,
  `IE_item` int(11) NOT NULL,
  `IE_value` varchar(128) DEFAULT NULL,
  `IE_desc` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`IE_effect`,`IE_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: itemMeta
DROP TABLE IF EXISTS `itemMeta`;
CREATE TABLE `itemMeta` (
  `IM_item` int(11) NOT NULL,
  `IM_meta` varchar(32) NOT NULL,
  `IM_value` text DEFAULT NULL,
  PRIMARY KEY (`IM_item`,`IM_meta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `itemMeta` VALUES ('1', 'cost', '100');
INSERT INTO `itemMeta` VALUES ('1', 'description', 'this gun will kill you');
INSERT INTO `itemMeta` VALUES ('1', 'equipLevel', '1');
INSERT INTO `itemMeta` VALUES ('2', 'cost', '100');
INSERT INTO `itemMeta` VALUES ('2', 'description', 'this gun is a featured listing');
INSERT INTO `itemMeta` VALUES ('2', 'equipLevel', '1');
INSERT INTO `itemMeta` VALUES ('3', 'cost', '100');
INSERT INTO `itemMeta` VALUES ('3', 'description', 'this gun is location based, set to Paris');
INSERT INTO `itemMeta` VALUES ('3', 'equipLevel', '1');
INSERT INTO `itemMeta` VALUES ('4', 'cost', '100');
INSERT INTO `itemMeta` VALUES ('4', 'description', 'A big red apple');
INSERT INTO `itemMeta` VALUES ('4', 'equipLevel', '1');
INSERT INTO `itemMeta` VALUES ('5', 'cost', '10');
INSERT INTO `itemMeta` VALUES ('5', 'description', 'its big and yellow');
INSERT INTO `itemMeta` VALUES ('5', 'equipLevel', '1');


-- Table: item_history
DROP TABLE IF EXISTS `item_history`;
CREATE TABLE `item_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `event_type` enum('created','bought','sold','traded','gifted','used','deleted','admin_given') NOT NULL,
  `from_user_id` int(11) DEFAULT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT 1,
  `price` bigint(20) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `event_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_item` (`item_id`),
  KEY `idx_from` (`from_user_id`),
  KEY `idx_to` (`to_user_id`),
  KEY `idx_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `item_history` VALUES ('1', '1', 'Desert Eagle', 'bought', NULL, '1', '1', '5000', NULL, '1763901981');
INSERT INTO `item_history` VALUES ('2', '1', 'Desert Eagle', 'traded', '1', '2', '1', '7000', NULL, '1763906981');
INSERT INTO `item_history` VALUES ('3', '1', 'Desert Eagle', 'sold', '2', NULL, '1', '6000', NULL, '1763909981');


-- Table: items
DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `I_id` int(11) NOT NULL AUTO_INCREMENT,
  `I_name` varchar(128) NOT NULL,
  `I_type` int(11) NOT NULL DEFAULT 0,
  `I_cost` int(11) DEFAULT 0,
  PRIMARY KEY (`I_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `items` VALUES ('1', 'gun 1', '1', '0');
INSERT INTO `items` VALUES ('2', 'gun 2', '1', '0');
INSERT INTO `items` VALUES ('3', 'gun 3', '1', '0');
INSERT INTO `items` VALUES ('4', 'apple', '3', '0');
INSERT INTO `items` VALUES ('5', 'A banana ', '1', '0');


-- Table: locations
DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations` (
  `L_id` int(11) NOT NULL AUTO_INCREMENT,
  `L_name` varchar(120) DEFAULT NULL,
  `L_cost` int(11) NOT NULL DEFAULT 0,
  `L_bullets` int(11) NOT NULL DEFAULT 0,
  `L_bulletCost` int(11) NOT NULL DEFAULT 100,
  `L_cooldown` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`L_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `locations` VALUES ('1', 'London', '170', '11977', '100', '3600');
INSERT INTO `locations` VALUES ('2', 'Paris', '200', '0', '100', '4200');
INSERT INTO `locations` VALUES ('3', 'Rome', '220', '0', '100', '4800');


-- Table: loginEvents
DROP TABLE IF EXISTS `loginEvents`;
CREATE TABLE `loginEvents` (
  `LE_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LE_time` int(10) unsigned NOT NULL,
  `LE_user` int(10) unsigned NOT NULL,
  `LE_ip` varchar(45) NOT NULL DEFAULT '',
  `LE_agent` varchar(255) NOT NULL DEFAULT '',
  `LE_type` enum('login','logout','register') NOT NULL DEFAULT 'login',
  PRIMARY KEY (`LE_id`),
  KEY `idx_time` (`LE_time`),
  KEY `idx_user_time` (`LE_user`,`LE_time`),
  KEY `idx_ip_time` (`LE_ip`(32),`LE_time`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `loginEvents` VALUES ('1', '1761748116', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('2', '1761753020', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('3', '1761778321', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('4', '1761827489', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('5', '1761833445', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('6', '1762253830', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('7', '1762253833', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('8', '1762253842', '4', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('9', '1762253846', '4', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('10', '1762253849', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('11', '1762545590', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('12', '1762545870', '1', '142.166.212.24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0', 'login');
INSERT INTO `loginEvents` VALUES ('13', '1762595778', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('14', '1762612010', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('15', '1762619874', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('16', '1762620036', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('17', '1762620063', '5', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'register');
INSERT INTO `loginEvents` VALUES ('18', '1762620066', '5', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('19', '1762620074', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('20', '1762622732', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('21', '1762622794', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('22', '1762636054', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('23', '1762674931', '1', '58.178.201.205', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 'login');
INSERT INTO `loginEvents` VALUES ('24', '1762676977', '1', '58.178.201.205', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 'logout');
INSERT INTO `loginEvents` VALUES ('25', '1762693207', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('26', '1762693591', '1', '5.198.78.25', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1', 'login');
INSERT INTO `loginEvents` VALUES ('27', '1762694544', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('28', '1762694555', '4', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('29', '1762719167', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('30', '1762726341', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('31', '1762735355', '1', '5.198.78.25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('32', '1762837514', '1', '58.178.201.205', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 'login');
INSERT INTO `loginEvents` VALUES ('33', '1762837636', '1', '58.178.201.205', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 'logout');
INSERT INTO `loginEvents` VALUES ('34', '1763906583', '2', '192.168.97.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15', 'logout');
INSERT INTO `loginEvents` VALUES ('35', '1763906592', '1', '192.168.97.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15', 'login');
INSERT INTO `loginEvents` VALUES ('36', '1763915871', '1', '192.168.97.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.105.1 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36', 'login');
INSERT INTO `loginEvents` VALUES ('37', '1763915900', '1', '192.168.97.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.105.1 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36', 'login');


-- Table: mail
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `M_id` int(11) NOT NULL AUTO_INCREMENT,
  `M_time` int(11) NOT NULL DEFAULT 0,
  `M_uid` int(11) NOT NULL DEFAULT 0,
  `M_sid` int(11) NOT NULL DEFAULT 0,
  `M_subject` varchar(120) DEFAULT NULL,
  `M_parent` int(11) NOT NULL DEFAULT 0,
  `M_text` text DEFAULT NULL,
  `M_type` int(11) NOT NULL DEFAULT 0,
  `M_read` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`M_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `mail` VALUES ('1', '1761678689', '1', '4', 'you ', '0', 'you are a bastard fuck', '0', '1');
INSERT INTO `mail` VALUES ('2', '1761701072', '1', '0', 'Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in ', '0', 'Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in a mute.', '0', '1');
INSERT INTO `mail` VALUES ('3', '1761701663', '1', '0', 'Final warning: You have 2 profanity infractions within the configured window. If you commit a third profanity infraction', '0', 'Final warning: You have 2 profanity infractions within the configured window. If you commit a third profanity infraction you will be muted for 60 minutes.', '0', '1');
INSERT INTO `mail` VALUES ('4', '1761701663', '0', '1', 'RE: Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result', '0', '**** ...', '0', '0');
INSERT INTO `mail` VALUES ('5', '1761701879', '1', '0', 'You have been muted', '0', 'You have been muted for 1 minutes due to repeated profanity.', '0', '1');
INSERT INTO `mail` VALUES ('6', '1761729999', '1', '0', 'You have been muted', '0', 'You have been muted for 1 minutes due to repeated profanity.', '0', '1');
INSERT INTO `mail` VALUES ('7', '1761739513', '1', '0', 'You have been muted', '0', 'You have been muted for 1 minutes due to repeated profanity.', '0', '1');
INSERT INTO `mail` VALUES ('8', '1761739513', '4', '1', 'hiiii', '0', '**** you', '0', '0');
INSERT INTO `mail` VALUES ('9', '1761748239', '1', '1', 'this is a test message', '0', 'warning ', '0', '1');
INSERT INTO `mail` VALUES ('10', '1761748239', '2', '1', 'this is a test message', '0', 'warning ', '0', '0');
INSERT INTO `mail` VALUES ('11', '1761748239', '3', '1', 'this is a test message', '0', 'warning ', '0', '0');
INSERT INTO `mail` VALUES ('12', '1761748239', '4', '1', 'this is a test message', '0', 'warning ', '0', '0');
INSERT INTO `mail` VALUES ('13', '1762622653', '1', '1', 'this is a new email test live', '0', 'live test email ', '0', '0');
INSERT INTO `mail` VALUES ('14', '1762622653', '2', '1', 'this is a new email test live', '0', 'live test email ', '0', '0');
INSERT INTO `mail` VALUES ('15', '1762622653', '3', '1', 'this is a new email test live', '0', 'live test email ', '0', '0');
INSERT INTO `mail` VALUES ('16', '1762622653', '4', '1', 'this is a new email test live', '0', 'live test email ', '0', '0');
INSERT INTO `mail` VALUES ('17', '1762622653', '5', '1', 'this is a new email test live', '0', 'live test email ', '0', '0');
INSERT INTO `mail` VALUES ('18', '1763823001', '1', '1', 'Test Email 1', '0', 'This is test message number 1. It contains some test content to demonstrate the mail archive functionality.', '1', '1');
INSERT INTO `mail` VALUES ('19', '1763736601', '1', '1', 'Test Email 2', '0', 'This is test message number 2. It contains some test content to demonstrate the mail archive functionality.', '0', '0');
INSERT INTO `mail` VALUES ('20', '1763650201', '1', '1', 'Test Email 3', '0', 'This is test message number 3. It contains some test content to demonstrate the mail archive functionality.', '1', '1');
INSERT INTO `mail` VALUES ('21', '1763563801', '1', '1', 'Test Email 4', '0', 'This is test message number 4. It contains some test content to demonstrate the mail archive functionality.', '0', '0');
INSERT INTO `mail` VALUES ('22', '1763477401', '1', '1', 'Test Email 5', '0', 'This is test message number 5. It contains some test content to demonstrate the mail archive functionality.', '1', '1');


-- Table: marketCategories
DROP TABLE IF EXISTS `marketCategories`;
CREATE TABLE `marketCategories` (
  `MC_id` int(11) NOT NULL AUTO_INCREMENT,
  `MC_key` varchar(64) DEFAULT NULL,
  `MC_name` varchar(64) DEFAULT NULL,
  `MC_desc` text DEFAULT NULL,
  `MC_sort` int(11) DEFAULT 0,
  `MC_active` tinyint(1) DEFAULT 1,
  `MC_location` int(11) DEFAULT NULL,
  PRIMARY KEY (`MC_id`),
  UNIQUE KEY `MC_key` (`MC_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `marketCategories` VALUES ('1', 'weapon', 'Weapon Store', 'weapon store', '0', '1', NULL);
INSERT INTO `marketCategories` VALUES ('2', 'armour', 'Armour Store', '', '0', '1', NULL);
INSERT INTO `marketCategories` VALUES ('3', 'clothes', 'Clothing Store', 'a place to buy clothing', '0', '1', NULL);
INSERT INTO `marketCategories` VALUES ('4', 'junk', 'Junk store', 'You can come here to sell unwanted items.', '0', '1', NULL);


-- Table: marketItems
DROP TABLE IF EXISTS `marketItems`;
CREATE TABLE `marketItems` (
  `MI_id` int(11) NOT NULL AUTO_INCREMENT,
  `MI_category` int(11) DEFAULT NULL,
  `MI_itemId` int(11) DEFAULT NULL,
  `MI_price` int(11) DEFAULT 0,
  `MI_pricePoints` int(11) DEFAULT 0,
  `MI_sellPrice` int(11) DEFAULT 0,
  `MI_stock` int(11) DEFAULT NULL,
  `MI_minRank` int(11) DEFAULT 0,
  `MI_limitPerUser` int(11) DEFAULT NULL,
  `MI_limitPerDay` int(11) DEFAULT NULL,
  `MI_featured` tinyint(1) DEFAULT 0,
  `MI_availableFrom` datetime DEFAULT NULL,
  `MI_availableTo` datetime DEFAULT NULL,
  `MI_taxable` tinyint(1) DEFAULT 1,
  `MI_active` tinyint(1) DEFAULT 1,
  `MI_restockQty` int(11) DEFAULT 0,
  `MI_stockCap` int(11) DEFAULT NULL,
  `MI_autoRestock` tinyint(1) DEFAULT 1,
  `MI_location` int(11) DEFAULT NULL,
  PRIMARY KEY (`MI_id`),
  KEY `MI_category` (`MI_category`),
  KEY `MI_itemId` (`MI_itemId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `marketItems` VALUES ('2', '1', '2', '100', '20', '0', '10', '0', NULL, '200', '0', NULL, NULL, '0', '1', '0', '10', '1', NULL);
INSERT INTO `marketItems` VALUES ('3', '1', '3', '200', '0', '10', '10', '0', NULL, '350', '0', NULL, NULL, '0', '1', '0', '10', '1', '2');
INSERT INTO `marketItems` VALUES ('4', '1', '1', '100', '0', '10', '100', '0', NULL, NULL, '1', NULL, NULL, '0', '1', '10', '100', '1', NULL);
INSERT INTO `marketItems` VALUES ('5', '4', '5', '10', '0', '10', '0', '0', NULL, NULL, '0', NULL, NULL, '0', '1', '10', '0', '1', NULL);
INSERT INTO `marketItems` VALUES ('6', '4', '4', '10', '0', '10', '0', '0', NULL, NULL, '0', NULL, NULL, '0', '1', '0', '0', '1', NULL);


-- Table: marketTransactions
DROP TABLE IF EXISTS `marketTransactions`;
CREATE TABLE `marketTransactions` (
  `MT_id` int(11) NOT NULL AUTO_INCREMENT,
  `MT_user` int(11) DEFAULT NULL,
  `MT_listing` int(11) DEFAULT NULL,
  `MT_itemId` int(11) DEFAULT NULL,
  `MT_qty` int(11) DEFAULT NULL,
  `MT_price` int(11) DEFAULT NULL,
  `MT_currency` varchar(16) DEFAULT NULL,
  `MT_tax` int(11) DEFAULT 0,
  `MT_total` int(11) DEFAULT NULL,
  `MT_type` varchar(8) DEFAULT NULL,
  `MT_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`MT_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `marketTransactions` VALUES ('9', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611023');
INSERT INTO `marketTransactions` VALUES ('10', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611030');
INSERT INTO `marketTransactions` VALUES ('11', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611031');
INSERT INTO `marketTransactions` VALUES ('12', '1', '1', '1', '1', '25', 'money', '0', '25', 'sell', '1761611032');
INSERT INTO `marketTransactions` VALUES ('13', '1', '1', '1', '1', '25', 'money', '0', '25', 'sell', '1761611033');
INSERT INTO `marketTransactions` VALUES ('14', '1', '1', '1', '100', '25', 'money', '0', '2500', 'sell', '1761611036');
INSERT INTO `marketTransactions` VALUES ('15', '1', '1', '1', '10', '25', 'money', '0', '250', 'sell', '1761611040');
INSERT INTO `marketTransactions` VALUES ('16', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611044');
INSERT INTO `marketTransactions` VALUES ('17', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611045');
INSERT INTO `marketTransactions` VALUES ('18', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761611045');
INSERT INTO `marketTransactions` VALUES ('19', '1', '1', '1', '1', '25', 'money', '0', '25', 'sell', '1761611049');
INSERT INTO `marketTransactions` VALUES ('20', '1', '1', '1', '1', '25', 'money', '0', '25', 'sell', '1761611049');
INSERT INTO `marketTransactions` VALUES ('21', '1', '1', '1', '1', '25', 'money', '0', '25', 'sell', '1761611051');
INSERT INTO `marketTransactions` VALUES ('22', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612868');
INSERT INTO `marketTransactions` VALUES ('23', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612870');
INSERT INTO `marketTransactions` VALUES ('24', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612871');
INSERT INTO `marketTransactions` VALUES ('25', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612872');
INSERT INTO `marketTransactions` VALUES ('26', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612872');
INSERT INTO `marketTransactions` VALUES ('27', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612873');
INSERT INTO `marketTransactions` VALUES ('28', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612874');
INSERT INTO `marketTransactions` VALUES ('29', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612875');
INSERT INTO `marketTransactions` VALUES ('30', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612875');
INSERT INTO `marketTransactions` VALUES ('31', '1', '4', '1', '1', '100', 'money', '0', '100', 'buy', '1761612876');
INSERT INTO `marketTransactions` VALUES ('32', '1', '5', '5', '1', '10', 'money', '0', '10', 'buy', '1761613270');
INSERT INTO `marketTransactions` VALUES ('33', '1', '6', '4', '1', '10', 'money', '0', '10', 'buy', '1761613276');
INSERT INTO `marketTransactions` VALUES ('34', '1', '5', '5', '1', '10', 'money', '0', '10', 'sell', '1761651929');
INSERT INTO `marketTransactions` VALUES ('35', '1', '6', '4', '1', '10', 'money', '0', '10', 'sell', '1761663171');
INSERT INTO `marketTransactions` VALUES ('36', '1', '4', '1', '10', '10', 'money', '0', '100', 'sell', '1761663413');
INSERT INTO `marketTransactions` VALUES ('37', '1', '5', '5', '1', '10', 'money', '0', '10', 'buy', '1763928501');
INSERT INTO `marketTransactions` VALUES ('38', '1', '5', '5', '1', '10', 'money', '0', '10', 'buy', '1763929572');
INSERT INTO `marketTransactions` VALUES ('39', '1', '5', '5', '1', '10', 'money', '0', '10', 'buy', '1763929575');


-- Table: marketTransactions_archive
DROP TABLE IF EXISTS `marketTransactions_archive`;
CREATE TABLE `marketTransactions_archive` (
  `MT_id` int(11) NOT NULL AUTO_INCREMENT,
  `MT_user` int(11) DEFAULT NULL,
  `MT_listing` int(11) DEFAULT NULL,
  `MT_itemId` int(11) DEFAULT NULL,
  `MT_qty` int(11) DEFAULT NULL,
  `MT_price` int(11) DEFAULT NULL,
  `MT_currency` varchar(16) DEFAULT NULL,
  `MT_tax` int(11) DEFAULT 0,
  `MT_total` int(11) DEFAULT NULL,
  `MT_type` varchar(8) DEFAULT NULL,
  `MT_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`MT_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `marketTransactions_archive` VALUES ('1', '1', '1', '1', '100', '100', 'money', '500', '10500', 'buy', '1761578748');
INSERT INTO `marketTransactions_archive` VALUES ('2', '2', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761580246');
INSERT INTO `marketTransactions_archive` VALUES ('3', '1', '1', '1', '6', '100', 'money', '30', '630', 'buy', '1761586696');
INSERT INTO `marketTransactions_archive` VALUES ('4', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761586699');
INSERT INTO `marketTransactions_archive` VALUES ('5', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761586700');
INSERT INTO `marketTransactions_archive` VALUES ('6', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761586700');
INSERT INTO `marketTransactions_archive` VALUES ('7', '1', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761586700');
INSERT INTO `marketTransactions_archive` VALUES ('8', '3', '1', '1', '1', '100', 'money', '5', '105', 'buy', '1761606338');


-- Table: market_price_history
DROP TABLE IF EXISTS `market_price_history`;
CREATE TABLE `market_price_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `transaction_type` enum('buy','sell') NOT NULL,
  `recorded_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_item` (`item_name`),
  KEY `idx_time` (`recorded_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `market_price_history` VALUES ('1', 'A banana ', '10', '1', 'buy', '1763928501');
INSERT INTO `market_price_history` VALUES ('2', 'A banana ', '10', '1', 'buy', '1763929572');
INSERT INTO `market_price_history` VALUES ('3', 'A banana ', '10', '1', 'buy', '1763929575');


-- Table: messagingLog
DROP TABLE IF EXISTS `messagingLog`;
CREATE TABLE `messagingLog` (
  `ML_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ML_time` int(10) unsigned NOT NULL,
  `ML_admin` int(10) unsigned NOT NULL,
  `ML_channel` enum('email','mail','both') NOT NULL,
  `ML_audience` varchar(255) NOT NULL,
  `ML_subject` varchar(255) NOT NULL,
  `ML_sent` int(10) unsigned NOT NULL DEFAULT 0,
  `ML_errors` int(10) unsigned NOT NULL DEFAULT 0,
  `ML_details` text DEFAULT NULL,
  PRIMARY KEY (`ML_id`),
  KEY `idx_time` (`ML_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `messagingLog` VALUES ('1', '1761748239', '1', 'mail', 'all', 'this is a test message', '4', '0', '');
INSERT INTO `messagingLog` VALUES ('2', '1762620227', '1', 'email', 'all', 'this is a test email', '5', '0', '');
INSERT INTO `messagingLog` VALUES ('3', '1762620694', '1', 'email', 'all', 'this is a test without smtp', '5', '0', '');
INSERT INTO `messagingLog` VALUES ('4', '1762622653', '1', 'mail', 'all', 'this is a new email test live', '5', '0', '');
INSERT INTO `messagingLog` VALUES ('5', '1762622684', '1', 'email', 'all', 'this is a live test email', '5', '0', '');


-- Table: moderation_actions
DROP TABLE IF EXISTS `moderation_actions`;
CREATE TABLE `moderation_actions` (
  `MA_id` int(11) NOT NULL AUTO_INCREMENT,
  `MA_user` int(11) NOT NULL,
  `MA_type` varchar(50) NOT NULL,
  `MA_reason` text DEFAULT NULL,
  `MA_actor` varchar(50) NOT NULL DEFAULT 'system',
  `MA_duration` int(11) DEFAULT 0,
  `MA_created` int(11) NOT NULL,
  `MA_expires` int(11) DEFAULT NULL,
  `MA_original` longtext DEFAULT NULL,
  PRIMARY KEY (`MA_id`),
  KEY `MA_user` (`MA_user`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `moderation_actions` VALUES ('1', '1', 'profanity', 'Profanity filtered in reply', 'system', '0', '1761701072', NULL, '{\"body\":\"            \\r\\n        fuck\"}');
INSERT INTO `moderation_actions` VALUES ('2', '1', 'warning', 'Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in a mute.', 'system', '0', '1761701072', NULL, '{\"body\":\"            \\r\\n        fuck\"}');
INSERT INTO `moderation_actions` VALUES ('3', '1', 'profanity', 'Profanity filtered in mail reply', 'system', '0', '1761701663', NULL, '{\"subject\":\"RE: Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in \",\"message\":\"fuck ...\"}');
INSERT INTO `moderation_actions` VALUES ('4', '1', 'warning', 'Final warning: You have 2 profanity infractions within the configured window. If you commit a third profanity infraction you will be muted for 60 minutes.', 'system', '0', '1761701663', NULL, '{\"subject\":\"RE: Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in \",\"message\":\"fuck ...\"}');
INSERT INTO `moderation_actions` VALUES ('5', '1', 'profanity', 'Profanity filtered in reply', 'system', '0', '1761701879', NULL, '{\"body\":\"            \\r\\n        fuck\"}');
INSERT INTO `moderation_actions` VALUES ('6', '1', 'mute', 'Auto-mute for repeated profanity', 'system', '60', '1761701879', '1761701939', NULL);
INSERT INTO `moderation_actions` VALUES ('7', '1', 'profanity', 'Profanity filtered in reply', 'system', '0', '1761729999', NULL, '{\"body\":\"            \\r\\n        fuck\"}');
INSERT INTO `moderation_actions` VALUES ('8', '1', 'mute', 'Auto-mute for repeated profanity', 'system', '60', '1761729999', '1761730059', NULL);
INSERT INTO `moderation_actions` VALUES ('9', '1', 'profanity', 'Profanity filtered in mail', 'system', '0', '1761739513', NULL, '{\"subject\":\"hiiii\",\"message\":\"fuck you\"}');
INSERT INTO `moderation_actions` VALUES ('10', '1', 'mute', 'Auto-mute for repeated profanity', 'system', '60', '1761739513', '1761739573', NULL);


-- Table: moneyRanks
DROP TABLE IF EXISTS `moneyRanks`;
CREATE TABLE `moneyRanks` (
  `MR_id` int(11) NOT NULL AUTO_INCREMENT,
  `MR_desc` varchar(128) DEFAULT NULL,
  `MR_money` int(11) DEFAULT NULL,
  PRIMARY KEY (`MR_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `moneyRanks` VALUES ('1', 'Broke', '0');
INSERT INTO `moneyRanks` VALUES ('2', 'Very Poor', '10000');
INSERT INTO `moneyRanks` VALUES ('3', 'Poor', '100000');
INSERT INTO `moneyRanks` VALUES ('4', 'Rich', '1000000');
INSERT INTO `moneyRanks` VALUES ('5', 'Very Rich', '10000000');


-- Table: notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `N_id` int(11) NOT NULL AUTO_INCREMENT,
  `N_uid` int(11) NOT NULL DEFAULT 0,
  `N_time` int(11) NOT NULL DEFAULT 0,
  `N_text` text DEFAULT NULL,
  `N_read` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`N_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `notifications` VALUES ('1', '1', '1761577288', 'GL V2 installed successfully', '1');
INSERT INTO `notifications` VALUES ('2', '1', '1761701072', 'Warning: Your recent post contained profanity. Please follow the community guidelines. Continued offenses may result in a mute.', '1');
INSERT INTO `notifications` VALUES ('3', '1', '1761701663', 'Final warning: You have 2 profanity infractions within the configured window. If you commit a third profanity infraction you will be muted for 60 minutes.', '0');
INSERT INTO `notifications` VALUES ('4', '1', '1761701879', 'You have been muted for 1 minutes due to repeated profanity.', '0');
INSERT INTO `notifications` VALUES ('5', '1', '1761729999', 'You have been muted for 1 minutes due to repeated profanity.', '0');
INSERT INTO `notifications` VALUES ('6', '1', '1761739513', 'You have been muted for 1 minutes due to repeated profanity.', '0');


-- Table: posts
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `P_id` int(11) NOT NULL AUTO_INCREMENT,
  `P_topic` int(11) DEFAULT NULL,
  `P_date` int(11) DEFAULT NULL,
  `P_user` int(11) DEFAULT NULL,
  `P_body` text DEFAULT NULL,
  PRIMARY KEY (`P_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `posts` VALUES ('1', '1', '1761656379', '1', 'If I type BADWORD in lowercase it will display badword');
INSERT INTO `posts` VALUES ('2', '1', '1761656393', '1', ' badword');
INSERT INTO `posts` VALUES ('4', '1', '1761701072', '1', ' ****');
INSERT INTO `posts` VALUES ('5', '1', '1761701879', '1', ' ****');
INSERT INTO `posts` VALUES ('6', '1', '1761729999', '1', ' ****');


-- Table: premiumMembership
DROP TABLE IF EXISTS `premiumMembership`;
CREATE TABLE `premiumMembership` (
  `PM_id` int(11) NOT NULL AUTO_INCREMENT,
  `PM_desc` varchar(255) NOT NULL,
  `PM_seconds` int(11) NOT NULL,
  `PM_cost` int(11) NOT NULL,
  PRIMARY KEY (`PM_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: properties
DROP TABLE IF EXISTS `properties`;
CREATE TABLE `properties` (
  `PR_id` int(11) NOT NULL AUTO_INCREMENT,
  `PR_location` int(11) NOT NULL,
  `PR_module` varchar(128) NOT NULL,
  `PR_user` int(11) NOT NULL DEFAULT 0,
  `PR_cost` int(11) NOT NULL DEFAULT 0,
  `PR_profit` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`PR_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: ranks
DROP TABLE IF EXISTS `ranks`;
CREATE TABLE `ranks` (
  `R_id` int(11) NOT NULL AUTO_INCREMENT,
  `R_name` varchar(100) DEFAULT NULL,
  `R_exp` int(11) NOT NULL DEFAULT 0,
  `R_limit` int(11) NOT NULL DEFAULT 0,
  `R_cashReward` int(11) NOT NULL DEFAULT 0,
  `R_health` int(11) NOT NULL DEFAULT 0,
  `R_bulletReward` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`R_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `ranks` VALUES ('1', 'Lowlife', '0', '0', '75', '5000', '25');
INSERT INTO `ranks` VALUES ('2', 'Thug', '50', '0', '150', '10000', '60');
INSERT INTO `ranks` VALUES ('3', 'Criminal', '100', '0', '250', '15000', '100');


-- Table: roleAccess
DROP TABLE IF EXISTS `roleAccess`;
CREATE TABLE `roleAccess` (
  `RA_role` int(11) NOT NULL,
  `RA_module` varchar(128) NOT NULL,
  PRIMARY KEY (`RA_role`,`RA_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `roleAccess` VALUES ('2', '*');


-- Table: rounds
DROP TABLE IF EXISTS `rounds`;
CREATE TABLE `rounds` (
  `R_id` int(11) NOT NULL AUTO_INCREMENT,
  `R_name` varchar(128) DEFAULT NULL,
  `R_start` int(11) DEFAULT NULL,
  `R_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`R_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `rounds` VALUES ('1', 'Round 1', '1761523200', '1766707200');


-- Table: settings
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `S_id` int(11) NOT NULL AUTO_INCREMENT,
  `S_desc` varchar(255) DEFAULT NULL,
  `S_value` text DEFAULT NULL,
  PRIMARY KEY (`S_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `settings` VALUES ('1', 'pointsName', 'Points');
INSERT INTO `settings` VALUES ('2', 'detectiveReport', '2');
INSERT INTO `settings` VALUES ('3', 'gangName', 'Gang');
INSERT INTO `settings` VALUES ('4', 'glCoreHash', '7067925084d4b4cec958b33b2f1a4d4a');
INSERT INTO `settings` VALUES ('5', 'validateUserEmail', '');
INSERT INTO `settings` VALUES ('6', 'itemTypes', '[{\"id\":1,\"name\":\"weapon\",\"type\":\"equip\"},{\"id\":2,\"name\":\"armor\",\"type\":\"equip\"},{\"id\":3,\"name\":\"consumable\",\"type\":\"use\"}]');
INSERT INTO `settings` VALUES ('7', 'game_name', 'LF test');
INSERT INTO `settings` VALUES ('8', 'theme', 'default');
INSERT INTO `settings` VALUES ('9', 'adminTheme', 'admin');
INSERT INTO `settings` VALUES ('10', 'landingPage', 'loggedin');
INSERT INTO `settings` VALUES ('11', 'membershipLinkName', 'Premium Membership');
INSERT INTO `settings` VALUES ('12', 'membershipName', 'Premium Member');
INSERT INTO `settings` VALUES ('13', 'from_email', '');
INSERT INTO `settings` VALUES ('14', 'maxBulletCost', '');
INSERT INTO `settings` VALUES ('15', 'bulletsStockMinPerHour', '');
INSERT INTO `settings` VALUES ('16', 'bulletsStockMaxPerHour', '');
INSERT INTO `settings` VALUES ('17', 'maxBulletBuy', '');
INSERT INTO `settings` VALUES ('18', 'market_taxRate', '5');
INSERT INTO `settings` VALUES ('19', 'market_restock_per_hour', '1');
INSERT INTO `settings` VALUES ('20', 'cron-marketplaceRestock', '1764176400');
INSERT INTO `settings` VALUES ('21', 'loginSuffix', '');
INSERT INTO `settings` VALUES ('22', 'loginPostfix', '');
INSERT INTO `settings` VALUES ('23', 'registerSuffix', '');
INSERT INTO `settings` VALUES ('24', 'registerPostfix', '');
INSERT INTO `settings` VALUES ('25', 'bankTax', '15');
INSERT INTO `settings` VALUES ('26', 'voteUrl', '');
INSERT INTO `settings` VALUES ('27', 'voteKey1', '');
INSERT INTO `settings` VALUES ('28', 'hospitalTimeUntillFull', '7200');
INSERT INTO `settings` VALUES ('29', 'hospitalmoneyUntillFull', '25000');
INSERT INTO `settings` VALUES ('30', 'lastBulletRestock', '1761606000');
INSERT INTO `settings` VALUES ('31', 'maxBulletStock', '40000');
INSERT INTO `settings` VALUES ('32', 'profanityFilter.config', '{\"enabled\":true,\"words\":[\"badword\",\"BADWORD\",\"bastard\",\"BASTARD\",\"fuck\",\"FUCK\"],\"wholeWord\":true,\"caseInsensitive\":true,\"mode\":\"mask\",\"maskChar\":\"*\",\"replacement\":\"***\"}');
INSERT INTO `settings` VALUES ('33', 'profanityFilter.moderation', '{\"enabled\":true,\"threshold\":3,\"window_days\":1,\"mute_duration\":60}');
INSERT INTO `settings` VALUES ('34', 'smtp_enabled', '1');
INSERT INTO `settings` VALUES ('35', 'smtp_host', 'in-v3.mailjet.com');
INSERT INTO `settings` VALUES ('36', 'smtp_port', '587');
INSERT INTO `settings` VALUES ('37', 'smtp_encryption', 'tls');
INSERT INTO `settings` VALUES ('38', 'smtp_user', '9f0b85aefb38f126b19a134421de1417');
INSERT INTO `settings` VALUES ('39', 'smtp_pass', '948038cb39e14c305b150ea35d823bef');
INSERT INTO `settings` VALUES ('40', 'smtp_from_email', 'lindonfewster@hotmail.co.uk');
INSERT INTO `settings` VALUES ('41', 'smtp_from_name', 'Testing GL');
INSERT INTO `settings` VALUES ('42', 'tinymce_api_key', 'dh0cdvkte9g6fdptxcslb2a90ioe5s71d1edrq5dnot80fax');
INSERT INTO `settings` VALUES ('43', 'voteMin', '');
INSERT INTO `settings` VALUES ('44', 'voteMax', '');
INSERT INTO `settings` VALUES ('45', 'voteKey2', '');


-- Table: theft
DROP TABLE IF EXISTS `theft`;
CREATE TABLE `theft` (
  `T_id` int(11) NOT NULL AUTO_INCREMENT,
  `T_name` varchar(255) DEFAULT NULL,
  `T_chance` int(11) NOT NULL DEFAULT 0,
  `T_maxDamage` int(11) NOT NULL DEFAULT 0,
  `T_worstCar` int(11) NOT NULL DEFAULT 0,
  `T_bestCar` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`T_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `theft` VALUES ('1', 'Steal from street corner', '50', '100', '1', '1000');
INSERT INTO `theft` VALUES ('2', 'Steel from 24hour car park', '35', '75', '1', '1000');
INSERT INTO `theft` VALUES ('3', 'Steal from private car park', '25', '60', '1', '2000');
INSERT INTO `theft` VALUES ('4', 'Steal from golf course', '18', '30', '500', '20000');
INSERT INTO `theft` VALUES ('5', 'Steal from car dearlership', '10', '10', '1000', '50000');


-- Table: topicReads
DROP TABLE IF EXISTS `topicReads`;
CREATE TABLE `topicReads` (
  `TR_topic` int(11) DEFAULT NULL,
  `TR_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


-- Table: topics
DROP TABLE IF EXISTS `topics`;
CREATE TABLE `topics` (
  `T_id` int(11) NOT NULL AUTO_INCREMENT,
  `T_date` int(11) DEFAULT NULL,
  `T_forum` int(11) DEFAULT NULL,
  `T_user` int(11) DEFAULT NULL,
  `T_subject` varchar(128) DEFAULT NULL,
  `T_type` int(11) DEFAULT NULL,
  `T_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`T_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `topics` VALUES ('1', '1761656379', '1', '1', 'this is a test topic ', NULL, NULL);


-- Table: userInventory
DROP TABLE IF EXISTS `userInventory`;
CREATE TABLE `userInventory` (
  `UI_user` int(11) NOT NULL,
  `UI_item` int(11) NOT NULL,
  `UI_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`UI_user`,`UI_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `userInventory` VALUES ('1', '5', '3');


-- Table: userRoles
DROP TABLE IF EXISTS `userRoles`;
CREATE TABLE `userRoles` (
  `UR_id` int(11) NOT NULL AUTO_INCREMENT,
  `UR_desc` varchar(128) DEFAULT NULL,
  `UR_color` varchar(7) NOT NULL,
  PRIMARY KEY (`UR_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `userRoles` VALUES ('1', 'User', '#777777');
INSERT INTO `userRoles` VALUES ('2', 'Admin', '#FFFFFF');
INSERT INTO `userRoles` VALUES ('3', 'Banned', '#FF0000');


-- Table: userStats
DROP TABLE IF EXISTS `userStats`;
CREATE TABLE `userStats` (
  `US_id` int(11) NOT NULL,
  `US_shotBy` int(11) NOT NULL DEFAULT 0,
  `US_health` int(11) NOT NULL DEFAULT 0,
  `US_exp` int(11) NOT NULL DEFAULT 0,
  `US_money` int(11) NOT NULL DEFAULT 250,
  `US_bank` int(11) NOT NULL DEFAULT 0,
  `US_bullets` int(11) NOT NULL DEFAULT 100,
  `US_backfire` int(11) NOT NULL DEFAULT 50,
  `US_points` int(11) NOT NULL DEFAULT 0,
  `US_pic` varchar(200) NOT NULL DEFAULT 'themes/default/images/default-profile-picture.png',
  `US_bio` varchar(1000) NOT NULL DEFAULT '0',
  `US_weapon` int(11) NOT NULL DEFAULT 0,
  `US_armor` int(11) NOT NULL DEFAULT 0,
  `US_rank` int(11) NOT NULL DEFAULT 1,
  `US_gang` int(11) NOT NULL DEFAULT 0,
  `US_location` int(11) NOT NULL DEFAULT 1,
  `US_crimes` varchar(255) NOT NULL DEFAULT '35-25-15-5-5-5-5-5-5-5-5-5-5-5-5',
  PRIMARY KEY (`US_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `userStats` VALUES ('1', '0', '0', '3', '1085', '0', '100', '0', '0', 'themes/default/images/default-profile-picture.png', '0', '0', '0', '1', '0', '1', '57-50');
INSERT INTO `userStats` VALUES ('2', '0', '0', '0', '1000', '0', '100', '0', '0', 'themes/default/images/default-profile-picture.png', '0', '0', '0', '1', '0', '1', '50-50');
INSERT INTO `userStats` VALUES ('3', '0', '0', '0', '1000', '0', '100', '0', '0', 'themes/default/images/default-profile-picture.png', '0', '0', '0', '1', '0', '1', '50-50');
INSERT INTO `userStats` VALUES ('4', '0', '0', '0', '1000', '0', '100', '0', '0', 'themes/default/images/default-profile-picture.png', '0', '0', '0', '1', '0', '1', '50-50');
INSERT INTO `userStats` VALUES ('5', '0', '0', '0', '1000', '0', '100', '0', '0', 'themes/default/images/default-profile-picture.png', '0', '0', '0', '1', '0', '1', '50-50');


-- Table: userTimers
DROP TABLE IF EXISTS `userTimers`;
CREATE TABLE `userTimers` (
  `UT_user` int(11) NOT NULL DEFAULT 0,
  `UT_desc` varchar(32) DEFAULT NULL,
  `UT_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `userTimers` VALUES ('1', 'laston', '1764179029');
INSERT INTO `userTimers` VALUES ('1', 'bullets', '1763928147');
INSERT INTO `userTimers` VALUES ('1', 'crime', '1763929650');
INSERT INTO `userTimers` VALUES ('1', 'hospital', '1763928147');
INSERT INTO `userTimers` VALUES ('1', 'jail', '1763928396');
INSERT INTO `userTimers` VALUES ('1', 'chase', '1763928147');
INSERT INTO `userTimers` VALUES ('1', 'theft', '1763928147');
INSERT INTO `userTimers` VALUES ('1', 'travel', '1763928147');
INSERT INTO `userTimers` VALUES ('1', 'membership', '1763928157');


-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `U_id` int(11) NOT NULL AUTO_INCREMENT,
  `U_name` varchar(30) DEFAULT NULL,
  `U_email` varchar(100) DEFAULT NULL,
  `U_password` varchar(255) NOT NULL DEFAULT '',
  `U_userLevel` int(1) DEFAULT NULL,
  `U_status` int(1) DEFAULT NULL,
  `U_round` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`U_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `users` VALUES ('1', 'test', 'test@test.com', '288fa5fc4a3b311a79c33edbc8ac0a96e7a4a58235a17216067f31dfe6d52a36', '2', '1', '1');
INSERT INTO `users` VALUES ('2', 'Searle', 'me@5earle.com', '195d9aa367a860c1ee925cd589d94f67b4f3b75b15a7978b05b1a07a2438940e', '1', '1', '1');
INSERT INTO `users` VALUES ('3', 'Manegus', 'manegus@manegus.com', 'a8a9f40a26f3d1bd7d3f2c413dfc01abb9dc4bb797b0fdbc8fd5f5ddb0f3c33e', '1', '1', '1');
INSERT INTO `users` VALUES ('4', 'demo', 'demo@demo.com', 'fe69715194d32a9dd954e4fa31ef9ffa81091d54e4368eee186e7da9f50f3931', '2', '1', '1');
INSERT INTO `users` VALUES ('5', 'lindon', 'lindonfewster93@gmail.com', '8d3050f870f9856f15446c3486ba50642250edf4f62306e73d30160a1e3be177', '1', '1', '1');


-- Table: weapons
DROP TABLE IF EXISTS `weapons`;
CREATE TABLE `weapons` (
  `W_id` int(11) NOT NULL AUTO_INCREMENT,
  `W_name` varchar(100) DEFAULT NULL,
  `W_accuracy` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`W_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `weapons` VALUES ('1', 'Pistol', '5');

SET FOREIGN_KEY_CHECKS=1;
